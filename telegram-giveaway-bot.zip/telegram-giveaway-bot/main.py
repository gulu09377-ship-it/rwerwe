import logging
import sqlite3
import json
import asyncio
import os
from datetime import datetime, timedelta
from telegram import (
    Update, 
    InlineKeyboardButton, 
    InlineKeyboardMarkup,
    WebAppInfo,
    LabeledPrice
)
from telegram.ext import (
    Application, 
    CommandHandler, 
    CallbackQueryHandler, 
    MessageHandler, 
    filters,
    ContextTypes,
    PreCheckoutQueryHandler
)
from flask import Flask, request, jsonify, send_from_directory
import threading
import requests

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Конфигурация из переменных окружения
BOT_TOKEN = os.environ.get('BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'hashcatx187077')
WEBAPP_URL = os.environ.get('WEBAPP_URL', 'https://your-bot-name.onrender.com')

# ============================================================
# 🧱 Flask сервер для WebApp
# ============================================================

app = Flask(__name__, static_folder='webapp')

# Serve the webapp
@app.route('/')
def serve_webapp():
    return send_from_directory('webapp', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('webapp', path)

# Получить данные розыгрыша
@app.route("/get_giveaway_info", methods=["GET"])
def get_giveaway_info():
    giveaway_id = request.args.get("giveaway_id")
    if not giveaway_id:
        return jsonify({"error": "Missing giveaway_id"}), 400

    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM giveaways WHERE id = ?', (giveaway_id,))
    giveaway = cursor.fetchone()
    conn.close()

    if not giveaway:
        return jsonify({"error": "Giveaway not found"}), 404

    return jsonify({
        "id": giveaway[0],
        "title": giveaway[1],
        "description": giveaway[2],
        "prize_fund": giveaway[3],
        "winners_count": giveaway[4],
        "channels": json.loads(giveaway[5]),
        "start_date": giveaway[6],
        "end_date": giveaway[7]
    })

# Проверка подписок пользователя
@app.route("/check_subscriptions", methods=["POST"])
def check_subscriptions():
    data = request.get_json()
    user_id = data.get("user_id")
    giveaway_id = data.get("giveaway_id")
    
    if not user_id or not giveaway_id:
        return jsonify({"error": "Missing user_id or giveaway_id"}), 400

    # Получаем информацию о розыгрыше
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('SELECT channels FROM giveaways WHERE id = ?', (giveaway_id,))
    giveaway = cursor.fetchone()
    conn.close()

    if not giveaway:
        return jsonify({"error": "Giveaway not found"}), 404

    channels = json.loads(giveaway[0])
    
    # Для демонстрации используем случайную проверку
    import random
    is_subscribed = random.random() > 0.3
    
    return jsonify({
        "subscribed": is_subscribed,
        "checked_channels": channels
    })

# Добавить участника в розыгрыш
@app.route("/add_participant", methods=["POST"])
def add_participant():
    data = request.get_json()
    user_id = data.get("user_id")
    giveaway_id = data.get("giveaway_id")
    
    if not user_id or not giveaway_id:
        return jsonify({"error": "Missing user_id or giveaway_id"}), 400
    
    success = add_participant_to_db(giveaway_id, user_id)
    
    return jsonify({
        "success": success,
        "message": "Участник добавлен в розыгрыш" if success else "Участник уже в розыгрыше"
    })

def add_participant_to_db(giveaway_id, user_id):
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    try:
        cursor.execute('INSERT INTO participants (giveaway_id, user_id) VALUES (?, ?)', (giveaway_id, user_id))
        conn.commit()
        success = True
    except sqlite3.IntegrityError:
        success = False
    conn.close()
    return success

# Health check endpoint
@app.route('/health')
def health_check():
    return jsonify({"status": "healthy", "timestamp": datetime.now().isoformat()})

# ============================================================
# 🗄️ Функции базы данных
# ============================================================

def init_db():
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    
    # Таблица пользователей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            last_name TEXT,
            balance INTEGER DEFAULT 0,
            is_admin BOOLEAN DEFAULT FALSE,
            joined_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Таблица розыгрышей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS giveaways (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            prize_fund INTEGER NOT NULL,
            winners_count INTEGER NOT NULL,
            channels TEXT NOT NULL,
            start_date TIMESTAMP,
            end_date TIMESTAMP,
            created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'active'
        )
    ''')
    
    # Таблица участников
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS participants (
            giveaway_id INTEGER,
            user_id INTEGER,
            joined_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (giveaway_id, user_id),
            FOREIGN KEY (giveaway_id) REFERENCES giveaways (id)
        )
    ''')
    
    # Таблица транзакций
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount INTEGER,
            type TEXT,
            description TEXT,
            date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

def get_user(user_id):
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    
    if user:
        return {
            'user_id': user[0],
            'username': user[1],
            'first_name': user[2],
            'last_name': user[3],
            'balance': user[4],
            'is_admin': bool(user[5])
        }
    return None

def create_user(user_id, username, first_name, last_name):
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT OR IGNORE INTO users (user_id, username, first_name, last_name) 
        VALUES (?, ?, ?, ?)
    ''', (user_id, username, first_name, last_name))
    conn.commit()
    conn.close()

def update_balance(user_id, amount):
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (amount, user_id))
    conn.commit()
    conn.close()

def set_admin(user_id):
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET is_admin = TRUE WHERE user_id = ?', (user_id,))
    conn.commit()
    conn.close()

def create_giveaway(title, description, prize_fund, winners_count, channels, start_date, end_date):
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO giveaways (title, description, prize_fund, winners_count, channels, start_date, end_date)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (title, description, prize_fund, winners_count, json.dumps(channels), start_date, end_date))
    giveaway_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return giveaway_id

def get_giveaways():
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM giveaways ORDER BY created_date DESC')
    giveaways = cursor.fetchall()
    conn.close()
    return giveaways

def get_giveaway(giveaway_id):
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM giveaways WHERE id = ?', (giveaway_id,))
    giveaway = cursor.fetchone()
    conn.close()
    return giveaway

def get_participants_count(giveaway_id):
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM participants WHERE giveaway_id = ?', (giveaway_id,))
    count = cursor.fetchone()[0]
    conn.close()
    return count

def is_participant(giveaway_id, user_id):
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM participants WHERE giveaway_id = ? AND user_id = ?', (giveaway_id, user_id))
    result = cursor.fetchone()
    conn.close()
    return result is not None

# ============================================================
# 🤖 Telegram Bot Handlers
# ============================================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    create_user(user.id, user.username, user.first_name, user.last_name)
    
    welcome_text = """
🌟 *Добро пожаловать в бота розыгрышей!* 🌟

🎁 *Что я умею:*
• Участвовать в розыгрышах с ценными призами
• Проверять подписки на каналы
• Управлять балансом Stars
• Получать уведомления о победах

💰 *Stars* - это внутренняя валюта бота, равная настоящим Telegram Stars!

📋 *Доступные команды:*
/menu - Главное меню
/balance - Мой баланс
/giveaways - Активные розыгрыши
/help - Помощь

🚀 *Начните с главного меню!*
    """
    
    keyboard = [
        [InlineKeyboardButton("🎮 Главное меню", callback_data="main_menu")],
        [InlineKeyboardButton("🎁 Активные розыгрыши", callback_data="active_giveaways")],
        [InlineKeyboardButton("💰 Мой баланс", callback_data="my_balance")],
        [InlineKeyboardButton("ℹ️ Помощь", callback_data="help")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.message:
        await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode='Markdown')
    else:
        await update.callback_query.edit_message_text(welcome_text, reply_markup=reply_markup, parse_mode='Markdown')

async def main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user = get_user(query.from_user.id)
    
    keyboard = [
        [InlineKeyboardButton("🎁 Активные розыгрыши", callback_data="active_giveaways")],
        [InlineKeyboardButton("💰 Пополнить баланс", callback_data="deposit")],
        [InlineKeyboardButton("💎 Мой баланс", callback_data="my_balance")],
        [InlineKeyboardButton("📊 Статистика", callback_data="stats")],
        [InlineKeyboardButton("ℹ️ Помощь", callback_data="help")]
    ]
    
    if user and user['is_admin']:
        keyboard.append([InlineKeyboardButton("👑 Админ панель", callback_data="admin_panel")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "🎮 *Главное меню*\n\nВыберите нужный раздел:",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def active_giveaways(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    giveaways = get_giveaways()
    active_giveaways = [g for g in giveaways if g[9] == 'active' and datetime.now() < datetime.fromisoformat(g[7])]
    
    if not active_giveaways:
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "🚫 *Активных розыгрышей нет*\n\nПроверьте позже или создайте свой розыгрыш!",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        return
    
    keyboard = []
    for giveaway in active_giveaways[:5]:
        participants_count = get_participants_count(giveaway[0])
        button_text = f"{giveaway[1]} ({participants_count} участ.)"
        keyboard.append([InlineKeyboardButton(button_text, callback_data=f"view_giveaway_{giveaway[0]}")])
    
    keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="main_menu")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "🎁 *Активные розыгрыши:*\n\nВыберите розыгрыш для участия:",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def view_giveaway(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    giveaway_id = int(query.data.split('_')[-1])
    giveaway = get_giveaway(giveaway_id)
    
    if not giveaway:
        await query.edit_message_text("❌ Розыгрыш не найден!")
        return
    
    participants_count = get_participants_count(giveaway_id)
    channels = json.loads(giveaway[5])
    is_participating = is_participant(giveaway_id, query.from_user.id)
    
    text = f"""
🎁 *{giveaway[1]}*

📝 *Описание:*
{giveaway[2]}

💰 *Призовой фонд:* {giveaway[3]} Stars
🎯 *Количество победителей:* {giveaway[4]}
👥 *Участников:* {participants_count}

📅 *Начало:* {giveaway[6]}
📅 *Окончание:* {giveaway[7]}

📢 *Необходимо подписаться на каналы:*
""" + "\n".join([f"• {channel}" for channel in channels])
    
    keyboard = []
    if not is_participating:
        keyboard.append([InlineKeyboardButton(
            "🚀 Участвовать в розыгрыше", 
            web_app=WebAppInfo(url=f"{WEBAPP_URL}?giveaway_id={giveaway_id}")
        )])
    
    keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="active_giveaways")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("1000 Stars 💫", callback_data="deposit_1000")],
        [InlineKeyboardButton("5000 Stars ⭐", callback_data="deposit_5000")],
        [InlineKeyboardButton("10000 Stars 🌟", callback_data="deposit_10000")],
        [InlineKeyboardButton("💎 Другое количество", callback_data="deposit_custom")],
        [InlineKeyboardButton("🔙 Назад", callback_data="main_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "💰 *Пополнение баланса*\n\n"
        "Выберите сумму для пополнения (минимум 1000 Stars):\n\n"
        "💎 1 Star = 1 Telegram Star",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def handle_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data == "deposit_custom":
        await query.edit_message_text(
            "💎 *Введите сумму для пополнения:*\n\n"
            "Минимальная сумма: 1000 Stars\n"
            "Пример: 2500",
            parse_mode='Markdown'
        )
        context.user_data['waiting_for_deposit'] = True
        return
    
    amount = int(query.data.split('_')[1])
    await create_invoice(update, context, amount)

async def create_invoice(update: Update, context: ContextTypes.DEFAULT_TYPE, amount: int):
    if hasattr(update, 'callback_query'):
        chat_id = update.callback_query.message.chat_id
    else:
        chat_id = update.message.chat_id
        
    prices = [LabeledPrice(f"{amount} Stars", amount)]
    
    try:
        await context.bot.send_invoice(
            chat_id=chat_id,
            title=f"Пополнение баланса на {amount} Stars",
            description=f"Пополнение внутреннего баланса бота на {amount} Stars",
            payload=f"deposit_{amount}_{chat_id}",
            provider_token="YOUR_PROVIDER_TOKEN",
            currency="XTR",
            prices=prices,
            start_parameter="deposit",
            need_name=False,
            need_email=False,
            need_phone_number=False,
            need_shipping_address=False
        )
    except Exception as e:
        logger.error(f"Error creating invoice: {e}")
        await context.bot.send_message(
            chat_id=chat_id,
            text="❌ Ошибка при создании платежа. Попробуйте позже."
        )

async def successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    amount = update.message.successful_payment.total_amount
    
    update_balance(user_id, amount)
    
    conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)',
        (user_id, amount, 'deposit', 'Пополнение баланса')
    )
    conn.commit()
    conn.close()
    
    await update.message.reply_text(
        f"✅ *Баланс успешно пополнен!*\n\n"
        f"💎 Зачислено: {amount} Stars\n"
        f"🎉 Теперь вы можете участвовать в розыгрышах!",
        parse_mode='Markdown'
    )

async def my_balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user = get_user(query.from_user.id)
    balance = user['balance'] if user else 0
    
    keyboard = [
        [InlineKeyboardButton("💰 Пополнить баланс", callback_data="deposit")],
        [InlineKeyboardButton("🔙 Назад", callback_data="main_menu")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        f"💎 *Ваш баланс:* {balance} Stars\n\n"
        "✨ Stars можно использовать для участия в розыгрышах и создания своих розыгрышей!",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user = get_user(query.from_user.id)
    giveaways = get_giveaways()
    active_giveaways_count = len([g for g in giveaways if g[9] == 'active'])
    
    keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="main_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        f"📊 *Ваша статистика:*\n\n"
        f"💎 Баланс: {user['balance'] if user else 0} Stars\n"
        f"🎁 Активных розыгрышей: {active_giveaways_count}",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="main_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    help_text = """
ℹ️ *Помощь по боту*

🎁 *Как участвовать в розыгрышах:*
1. Перейдите в "Активные розыгрыши"
2. Выберите интересующий розыгрыш
3. Нажмите "Участвовать"
4. Подпишитесь на необходимые каналы
5. Нажмите "Проверить подписки"

💰 *Как пополнить баланс:*
1. Перейдите в "Пополнить баланс"
2. Выберите сумму
3. Оплатите через Telegram Stars
4. Баланс пополнится автоматически

💎 *Что такое Stars:*
• 1 Star = 1 Telegram Star
• Можно выиграть в розыгрышах

🎯 *Правила:*
• Один пользователь может участвовать один раз в каждом розыгрыше
• Подписки проверяются автоматически
• Победители выбираются случайным образом
    """
    
    await query.edit_message_text(help_text, reply_markup=reply_markup, parse_mode='Markdown')

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user = get_user(query.from_user.id)
    if not user or not user['is_admin']:
        await query.edit_message_text("🚫 У вас нет доступа к админ панели!")
        return
    
    keyboard = [
        [InlineKeyboardButton("➕ Создать розыгрыш", callback_data="admin_create_giveaway")],
        [InlineKeyboardButton("📊 Все розыгрыши", callback_data="admin_all_giveaways")],
        [InlineKeyboardButton("💎 Начислить Stars", callback_data="admin_add_stars")],
        [InlineKeyboardButton("👥 Пользователи", callback_data="admin_users")],
        [InlineKeyboardButton("🔙 Главное меню", callback_data="main_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "👑 *Админ панель*\n\nВыберите действие:",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def admin_create_giveaway(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user = get_user(query.from_user.id)
    if not user or not user['is_admin']:
        await query.edit_message_text("🚫 У вас нет доступа!")
        return
    
    context.user_data['creating_giveaway'] = True
    context.user_data['giveaway_step'] = 'title'
    
    await query.edit_message_text(
        "🎁 *Создание нового розыгрыша*\n\n"
        "Шаг 1/7: Введите название розыгрыша:",
        parse_mode='Markdown'
    )

async def handle_giveaway_creation(update: Update, context: ContextTypes.DEFAULT_TYPE, message_text: str):
    user_id = update.effective_user.id
    user = get_user(user_id)
    
    if not user or not user['is_admin']:
        return
    
    if not context.user_data.get('creating_giveaway'):
        return
    
    step = context.user_data.get('giveaway_step')
    
    if step == 'title':
        context.user_data['giveaway_title'] = message_text
        context.user_data['giveaway_step'] = 'description'
        await update.message.reply_text(
            "📝 *Шаг 2/7:* Введите описание розыгрыша:",
            parse_mode='Markdown'
        )
        
    elif step == 'description':
        context.user_data['giveaway_description'] = message_text
        context.user_data['giveaway_step'] = 'prize_fund'
        await update.message.reply_text(
            "💰 *Шаг 3/7:* Введите призовой фонд (в Stars):",
            parse_mode='Markdown'
        )
        
    elif step == 'prize_fund':
        try:
            prize_fund = int(message_text)
            if prize_fund < 1:
                await update.message.reply_text("❌ Призовой фонд должен быть положительным числом!")
                return
                
            context.user_data['giveaway_prize_fund'] = prize_fund
            context.user_data['giveaway_step'] = 'winners_count'
            await update.message.reply_text(
                "🎯 *Шаг 4/7:* Введите количество победителей:",
                parse_mode='Markdown'
            )
        except ValueError:
            await update.message.reply_text("❌ Введите корректное число!")
            
    elif step == 'winners_count':
        try:
            winners_count = int(message_text)
            if winners_count < 1:
                await update.message.reply_text("❌ Количество победителей должно быть положительным числом!")
                return
                
            context.user_data['giveaway_winners_count'] = winners_count
            context.user_data['giveaway_step'] = 'channels'
            await update.message.reply_text(
                "📢 *Шаг 5/7:* Введите ссылки на каналы (через запятую):\n\n"
                "Пример: https://t.me/channel1, https://t.me/channel2",
                parse_mode='Markdown'
            )
        except ValueError:
            await update.message.reply_text("❌ Введите корректное число!")
            
    elif step == 'channels':
        channels = [channel.strip() for channel in message_text.split(',')]
        
        if not channels or all(not channel for channel in channels):
            await update.message.reply_text("❌ Введите хотя бы одну ссылку на канал!")
            return
            
        context.user_data['giveaway_channels'] = channels
        context.user_data['giveaway_step'] = 'start_date'
        await update.message.reply_text(
            "📅 *Шаг 6/7:* Введите дату начала розыгрыша (в формате ДД.ММ.ГГГГ ЧЧ:ММ):\n\n"
            "Пример: 25.12.2024 18:00\n"
            "Или введите 'сейчас' для начала сразу",
            parse_mode='Markdown'
        )
        
    elif step == 'start_date':
        if message_text.lower() == 'сейчас':
            start_date = datetime.now()
        else:
            try:
                start_date = datetime.strptime(message_text, '%d.%m.%Y %H:%M')
                if start_date < datetime.now():
                    await update.message.reply_text("❌ Дата начала не может быть в прошлом!")
                    return
            except ValueError:
                await update.message.reply_text("❌ Неправильный формат даты! Используйте ДД.ММ.ГГГГ ЧЧ:ММ")
                return
        
        context.user_data['giveaway_start_date'] = start_date
        context.user_data['giveaway_step'] = 'end_date'
        await update.message.reply_text(
            "📅 *Шаг 7/7:* Введите дату окончания розыгрыша (в формате ДД.ММ.ГГГГ ЧЧ:ММ):\n\n"
            "Пример: 31.12.2024 23:59",
            parse_mode='Markdown'
        )
        
    elif step == 'end_date':
        try:
            end_date = datetime.strptime(message_text, '%d.%m.%Y %H:%M')
            start_date = context.user_data['giveaway_start_date']
            
            if end_date <= start_date:
                await update.message.reply_text("❌ Дата окончания должна быть позже даты начала!")
                return
                
            if end_date <= datetime.now():
                await update.message.reply_text("❌ Дата окончания не может быть в прошлом!")
                return
                
        except ValueError:
            await update.message.reply_text("❌ Неправильный формат даты! Используйте ДД.ММ.ГГГГ ЧЧ:ММ")
            return
        
        giveaway_id = create_giveaway(
            title=context.user_data['giveaway_title'],
            description=context.user_data['giveaway_description'],
            prize_fund=context.user_data['giveaway_prize_fund'],
            winners_count=context.user_data['giveaway_winners_count'],
            channels=context.user_data['giveaway_channels'],
            start_date=context.user_data['giveaway_start_date'],
            end_date=end_date
        )
        
        participate_button = InlineKeyboardButton(
            "🚀 Участвовать в розыгрыше", 
            web_app=WebAppInfo(url=f"{WEBAPP_URL}?giveaway_id={giveaway_id}")
        )
        
        keyboard = [[participate_button]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        giveaway_text = f"""
🎉 *НОВЫЙ РОЗЫГРЫШ!* 🎉

🎁 *{context.user_data['giveaway_title']}*

📝 *Описание:*
{context.user_data['giveaway_description']}

💰 *Призовой фонд:* {context.user_data['giveaway_prize_fund']} Stars
🎯 *Количество победителей:* {context.user_data['giveaway_winners_count']}

📢 *Необходимо подписаться на каналы:*
""" + "\n".join([f"• {channel}" for channel in context.user_data['giveaway_channels']]) + f"""

📅 *Начало:* {context.user_data['giveaway_start_date'].strftime('%d.%m.%Y %H:%M')}
📅 *Окончание:* {end_date.strftime('%d.%m.%Y %H:%M')}

👇 *Нажмите кнопку ниже для участия!*
        """
        
        await update.message.reply_text(
            giveaway_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
        for key in ['creating_giveaway', 'giveaway_step', 'giveaway_title', 'giveaway_description', 
                   'giveaway_prize_fund', 'giveaway_winners_count', 'giveaway_channels', 'giveaway_start_date']:
            context.user_data.pop(key, None)

async def admin_all_giveaways(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user = get_user(query.from_user.id)
    if not user or not user['is_admin']:
        await query.edit_message_text("🚫 У вас нет доступа!")
        return
    
    giveaways = get_giveaways()
    
    if not giveaways:
        await query.edit_message_text("📊 Розыгрышей пока нет.")
        return
    
    text = "📊 *Все розыгрыши:*\n\n"
    for giveaway in giveaways[:10]:
        participants_count = get_participants_count(giveaway[0])
        status = "🟢 Активен" if giveaway[9] == 'active' else "🔴 Завершен"
        text += f"🎁 {giveaway[1]}\n"
        text += f"   👥 Участников: {participants_count}\n"
        text += f"   🏆 Победителей: {giveaway[4]}\n"
        text += f"   💰 Приз: {giveaway[3]} Stars\n"
        text += f"   📅 До: {giveaway[7][:10]}\n"
        text += f"   {status}\n\n"
    
    keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="admin_panel")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def admin_add_stars(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user = get_user(query.from_user.id)
    if not user or not user['is_admin']:
        await query.edit_message_text("🚫 У вас нет доступа!")
        return
    
    await query.edit_message_text(
        "💎 *Начисление Stars*\n\n"
        "Для начисления Stars пользователю отправьте сообщение в формате:\n"
        "`/addstars user_id amount`\n\n"
        "Пример: `/addstars 123456789 1000`",
        parse_mode='Markdown'
    )

async def add_stars_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = get_user(update.effective_user.id)
    if not user or not user['is_admin']:
        await update.message.reply_text("🚫 У вас нет доступа к этой команде!")
        return
    
    if len(context.args) != 2:
        await update.message.reply_text(
            "❌ Неправильный формат команды!\n"
            "Используйте: `/addstars user_id amount`\n"
            "Пример: `/addstars 123456789 1000`",
            parse_mode='Markdown'
        )
        return
    
    try:
        user_id = int(context.args[0])
        amount = int(context.args[1])
        
        if amount <= 0:
            await update.message.reply_text("❌ Количество Stars должно быть положительным!")
            return
        
        update_balance(user_id, amount)
        
        conn = sqlite3.connect('giveaway_bot.db', check_same_thread=False)
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)',
            (user_id, amount, 'admin_add', f'Начисление админом {update.effective_user.id}')
        )
        conn.commit()
        conn.close()
        
        await update.message.reply_text(
            f"✅ *Stars успешно начислены!*\n\n"
            f"👤 Пользователь: {user_id}\n"
            f"💎 Количество: {amount} Stars",
            parse_mode='Markdown'
        )
        
    except ValueError:
        await update.message.reply_text("❌ Неправильный формат чисел!")

async def admin_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user = get_user(query.from_user.id)
    if not user or not user['is_admin']:
        await query.edit_message_text("🚫 У вас нет доступа!")
        return
    
    await query.edit_message_text(
        "👥 *Управление пользователями*\n\n"
        "Для начисления Stars:\n"
        "`/addstars user_id amount`",
        parse_mode='Markdown'
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message_text = update.message.text
    user_id = update.effective_user.id
    
    if context.user_data.get('waiting_for_deposit'):
        try:
            amount = int(message_text)
            if amount < 1000:
                await update.message.reply_text("❌ Минимальная сумма 1000 Stars!")
                return
            
            await create_invoice(update, context, amount)
            context.user_data['waiting_for_deposit'] = False
            
        except ValueError:
            await update.message.reply_text("❌ Пожалуйста, введите корректное число!")
        return
    
    if message_text == ADMIN_PASSWORD:
        set_admin(user_id)
        await update.message.reply_text(
            "✅ *Вы получили доступ к админ панели!*\n\n"
            "Теперь вы можете использовать команду /admin для доступа к админским функциям.",
            parse_mode='Markdown'
        )
        return
    
    if context.user_data.get('creating_giveaway'):
        await handle_giveaway_creation(update, context, message_text)
        return
    
    await update.message.reply_text(
        "Не понимаю команду. Используйте /menu для открытия меню."
    )

async def pre_checkout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.pre_checkout_query
    await query.answer(ok=True)

# ============================================================
# 🚀 Запуск Telegram бота
# ============================================================

def run_bot():
    """Запуск Telegram бота в отдельном потоке"""
    try:
        init_db()
        
        application = Application.builder().token(BOT_TOKEN).build()
        
        # Добавляем обработчики
        application.add_handler(CommandHandler("start", start))
        application.add_handler(CommandHandler("menu", main_menu))
        application.add_handler(CommandHandler("admin", admin_panel))
        application.add_handler(CommandHandler("balance", my_balance))
        application.add_handler(CommandHandler("help", help_command))
        application.add_handler(CommandHandler("addstars", add_stars_command))
        
        application.add_handler(CallbackQueryHandler(main_menu, pattern="^main_menu$"))
        application.add_handler(CallbackQueryHandler(active_giveaways, pattern="^active_giveaways$"))
        application.add_handler(CallbackQueryHandler(deposit, pattern="^deposit$"))
        application.add_handler(CallbackQueryHandler(handle_deposit, pattern="^deposit_"))
        application.add_handler(CallbackQueryHandler(view_giveaway, pattern="^view_giveaway_"))
        application.add_handler(CallbackQueryHandler(my_balance, pattern="^my_balance$"))
        application.add_handler(CallbackQueryHandler(stats, pattern="^stats$"))
        application.add_handler(CallbackQueryHandler(help_command, pattern="^help$"))
        application.add_handler(CallbackQueryHandler(admin_panel, pattern="^admin_panel$"))
        application.add_handler(CallbackQueryHandler(admin_create_giveaway, pattern="^admin_create_giveaway$"))
        application.add_handler(CallbackQueryHandler(admin_all_giveaways, pattern="^admin_all_giveaways$"))
        application.add_handler(CallbackQueryHandler(admin_add_stars, pattern="^admin_add_stars$"))
        application.add_handler(CallbackQueryHandler(admin_users, pattern="^admin_users$"))
        
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
        
        application.add_handler(PreCheckoutQueryHandler(pre_checkout))
        application.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment))
        
        print("🤖 Telegram бот запущен...")
        application.run_polling()
    except Exception as e:
        print(f"❌ Ошибка запуска бота: {e}")
        # Перезапуск через 60 секунд при ошибке
        import time
        time.sleep(60)
        run_bot()

# Запускаем бота в отдельном потоке при старте приложения
@app.before_first_request
def startup():
    """Запуск бота при старте Flask приложения"""
    bot_thread = threading.Thread(target=run_bot, daemon=True)
    bot_thread.start()
    print("✅ Бот запущен в фоновом потоке")

# ============================================================
# 🎯 Точка входа для Render.com
# ============================================================

if __name__ == '__main__':
    # Для локального запуска
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)